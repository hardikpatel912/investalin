package com.investallign.interfaces;

public interface ResponseListener {

     void onResponse(Object object);
}
