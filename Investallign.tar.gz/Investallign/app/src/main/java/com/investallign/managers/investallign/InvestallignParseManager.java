package com.investallign.managers.investallign;


public class InvestallignParseManager {

    private InvestallignParseManager() {
    }

//    public static PageDetailKhelmahakumbhResponseEntity parseAboutusDetails(String json) {
//
//        PageDetailKhelmahakumbhResponseEntity pageDetailKhelmahakumbhResponseEntity = null;
//
//        pageDetailKhelmahakumbhResponseEntity =  PageDetailKhelmahakumbhResponseEntity.parse(json);
//        return pageDetailKhelmahakumbhResponseEntity;
//    }


}
