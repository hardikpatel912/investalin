package com.investallign.interfaces;

/**
 * Created by dhavalpatel on 26/11/15.
 */
public interface OnPageChangeListener {

    void onPage();
}
