package com.investallign.interfaces;

public interface ParseListener {

     Object onParse(String jsonString);
}
